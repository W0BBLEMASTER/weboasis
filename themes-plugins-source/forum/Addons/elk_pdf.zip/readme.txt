[center][size=16pt][b]Print to PDF[/b][/size][/center]
[hr]

[color=blue][b][size=12pt][u]License[/u][/size][/b][/color]
This Elkarte addon is released under a BSD-3-Clause license.

[color=blue][b][size=12pt][u]Introduction[/u][/size][/b][/color]
This addon replaces the print button action to instead create a PDF of the topic for viewing / saving.

[color=blue][b][size=12pt][u]Dependencies[/u][/size][/b][/color]
Utilizes tFPDF (based on FPDF) by Ian Back, License:  LGPL

[color=blue][b][size=12pt][u]Features[/u][/size][/b][/color]
 o One-click creation of topic PDF's
 o Includes topic image attachments in the PDF
 o Maintains some basic text formatting
 o No source edits, all done with hooks.

[color=blue][b][size=12pt][u]Repo[/u][/size][/b][/color]
https://bitbucket.org/spuds_/elk_pdf
[color=blue][b][size=12pt][u]Source[/u][/size][/b][/color]
https://bitbucket.org/spuds_/elk_pdf/src
[color=blue][b][size=12pt][u]Download[/u][/size][/b][/color]
https://bitbucket.org/spuds_/elk_pdf/downloads